package consts

const (
	CaptchaTypeString = iota + 1 // 字符串
	CaptchaTypeMath              // 数字计算
)
