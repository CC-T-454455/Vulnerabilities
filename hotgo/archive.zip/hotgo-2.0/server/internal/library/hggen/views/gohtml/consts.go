package gohtml

const (
	defaultIndentString = "  "
	startIndent         = 0
	defaultLastElement  = "</html>"
)
