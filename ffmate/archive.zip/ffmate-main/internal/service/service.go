package service

const (
	Preset      = "preset"
	Webhook     = "webhook"
	Watchfolder = "watchfolder"
	Task        = "task"
	Websocket   = "websocket"
	Telemetry   = "telemetry"
	Tray        = "tray"
	FFMpeg      = "ffmpeg"
	Settings    = "settings"
	Client      = "client"
	Update      = "update"
)
