package dto

type Settings struct {
}
