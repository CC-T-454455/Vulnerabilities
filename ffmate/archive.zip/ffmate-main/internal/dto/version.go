package dto

type Version struct {
	Version string `json:"version"`
}
