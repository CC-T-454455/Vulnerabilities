package dto

type Telemetry struct {
}
