import Tool from './tool.vue'

export default Tool 