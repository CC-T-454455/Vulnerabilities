import Agent from './agent.vue'

export default Agent 