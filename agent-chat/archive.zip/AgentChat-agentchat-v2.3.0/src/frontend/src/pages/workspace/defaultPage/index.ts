import DefaultPage from './defaultPage.vue'

export default DefaultPage



