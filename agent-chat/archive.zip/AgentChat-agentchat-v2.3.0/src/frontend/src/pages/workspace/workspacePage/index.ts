import WorkspacePage from './workspacePage.vue'

export default WorkspacePage



