import Configuration from './configuration.vue'

export default Configuration
