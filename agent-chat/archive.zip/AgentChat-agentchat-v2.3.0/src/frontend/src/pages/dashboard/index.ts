import Dashboard from './dashboard.vue'

export default Dashboard

