
import NotFound from './notFound.vue'

export default NotFound
