import Construct from "./construct.vue";

export default  Construct
