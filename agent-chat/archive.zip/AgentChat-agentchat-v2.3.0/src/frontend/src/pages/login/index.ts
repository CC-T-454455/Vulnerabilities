import Login from './login.vue'
import Register from './register.vue'

export { Login, Register }
export default Login 