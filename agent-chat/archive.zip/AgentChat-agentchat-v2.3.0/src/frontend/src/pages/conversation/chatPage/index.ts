import ChatPage from "./chatPage.vue";

export default ChatPage