import Knowledge from './knowledge.vue'

export default Knowledge 