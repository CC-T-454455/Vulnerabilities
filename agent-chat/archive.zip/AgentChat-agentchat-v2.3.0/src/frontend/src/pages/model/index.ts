import Model from './model.vue'

export default Model 