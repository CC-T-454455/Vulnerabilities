import McpServer from './mcp-server.vue'

export default McpServer 