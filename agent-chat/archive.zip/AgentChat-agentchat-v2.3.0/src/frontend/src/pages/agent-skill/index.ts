import AgentSkill from './agent-skill.vue'

export default AgentSkill
export { AgentSkill }
