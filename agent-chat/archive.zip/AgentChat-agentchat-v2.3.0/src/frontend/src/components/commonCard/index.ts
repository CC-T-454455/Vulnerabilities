import CommonCard from "./commonCard.vue";

export default CommonCard