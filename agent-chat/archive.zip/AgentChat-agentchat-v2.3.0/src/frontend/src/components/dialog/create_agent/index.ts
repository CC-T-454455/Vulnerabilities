import CreateAgent from "./create_agent.vue";

export default CreateAgent
