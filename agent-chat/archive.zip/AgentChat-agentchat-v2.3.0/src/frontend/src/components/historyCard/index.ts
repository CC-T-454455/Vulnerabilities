import HistortCard from './histortCard.vue'

export default HistortCard