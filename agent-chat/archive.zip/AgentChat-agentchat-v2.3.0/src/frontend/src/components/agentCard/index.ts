import AgentCard from "./agentCard.vue";

export default AgentCard 
