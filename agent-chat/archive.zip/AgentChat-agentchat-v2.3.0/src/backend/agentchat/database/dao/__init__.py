from sqlmodel import create_engine

# engine = create_engine(MYSQL_URL, connect_args={"charset": "utf8mb4"})