McpAsToolPrompt = """
请你根据工具描述来生成一个mcp_as_tool_name 和 description的Json数据格式

{tools_info}
"""