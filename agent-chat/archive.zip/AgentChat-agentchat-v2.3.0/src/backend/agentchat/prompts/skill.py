AgentSkillAsToolPrompt = """
请你根据工具描述来生成一个as_tool_name的Json数据格式

# 技能中文名称
{name}

# 技能描述
{description}
"""