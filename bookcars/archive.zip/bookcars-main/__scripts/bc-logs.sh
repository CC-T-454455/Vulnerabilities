#!/usr/bin/env bash

tail -f /opt/bookcars/backend/logs/all.log
