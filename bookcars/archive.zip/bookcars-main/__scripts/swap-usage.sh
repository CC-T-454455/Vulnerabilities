#!/bin/bash

grep '^Swap' /proc/meminfo
