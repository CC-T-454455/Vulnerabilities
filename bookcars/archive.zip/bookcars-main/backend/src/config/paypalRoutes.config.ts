const routes = {
  createPayPalOrder: '/api/create-paypal-order',
  checkPayPalOrder: '/api/check-paypal-order/:bookingId/:orderId',
}

export default routes
