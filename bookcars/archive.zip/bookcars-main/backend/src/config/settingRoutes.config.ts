export default {
  getSettings: '/api/settings',
  updateSettings: '/api/update-settings',
}
