const routes = {
  upsert: '/api/upsert-bank-details',
  get: '/api/bank-details',
}

export default routes
